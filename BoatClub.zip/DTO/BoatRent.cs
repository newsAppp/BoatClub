namespace BoatClub.DTO
{
    public class BoatRent
    {
        public int BoatId { get; set; } 
        public string CustomerName { get; set; } 
    }
}