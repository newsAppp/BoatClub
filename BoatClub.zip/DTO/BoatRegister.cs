namespace BoatClub.DTO
{
    public class BoatRegister
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Image { get; set; }
        public double HourlyRate { get; set; }
    }
}