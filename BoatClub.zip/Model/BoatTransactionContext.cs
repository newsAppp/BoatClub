namespace BoatClub.Model
{
    public class BoatTransactionContext
    {
    }
}