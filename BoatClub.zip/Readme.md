assumption

1. rent customer name validation, not required